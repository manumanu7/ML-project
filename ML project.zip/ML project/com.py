import pickle
from flask import Flask,render_template,request,jsonify
from flask import Flask,redirect,url_for,render_template,request,flash

from tkinter.filedialog import *

import PIL
from PIL import Image   

#pickle.load(open('cancer.pkl', 'rb'))

app=Flask(__name__,template_folder='templates')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/compress',methods =["GET", "POST"])
def compression():
    if request.method == "POST":
        #y=request.form.get('inputfile')
        x=askopenfilename()
        img=PIL.Image.open(x)
        myHeight,myWidth=img.size

        img=img.resize((myHeight,myWidth) ,PIL.Image.ANTIALIAS) 
        
        sp=asksaveasfilename()

        img.show()

        img.save(sp+".jpg")

        return "Downloaded"

    return "Metho has to be post"





if __name__ == "__main__":
    app.run(debug=True)